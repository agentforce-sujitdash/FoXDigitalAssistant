import { LightningElement } from 'lwc';

export default class FoxTeamOverview extends LightningElement {}
