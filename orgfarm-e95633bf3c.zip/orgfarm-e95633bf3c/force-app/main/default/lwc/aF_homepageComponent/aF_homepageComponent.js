import { LightningElement } from 'lwc';
import genaiIcon from '@salesforce/resourceUrl/genaiIcon';
import coveoIcon from '@salesforce/resourceUrl/coveoIcon';
import caseIcon from '@salesforce/resourceUrl/caseIcon';
import convoIcon from '@salesforce/resourceUrl/convoIcon';
import authIcon from '@salesforce/resourceUrl/authIcon';
import livechat from '@salesforce/resourceUrl/livechat';

export default class AskFoxAgent extends LightningElement {
    genaiIcon = genaiIcon;
    coveoIcon = coveoIcon;
    caseIcon = caseIcon;
    convoIcon = convoIcon;
    authIcon = authIcon;
    livechat = livechat;
}
