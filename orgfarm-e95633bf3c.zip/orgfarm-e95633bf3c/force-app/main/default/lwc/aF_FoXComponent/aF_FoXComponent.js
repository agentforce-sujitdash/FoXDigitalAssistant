import { LightningElement } from 'lwc';
import foxLogo from '@salesforce/resourceUrl/foxLogo';

export default class FoxTeamPromo extends LightningElement {
    logoUrl = foxLogo;
}
